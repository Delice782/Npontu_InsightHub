<!DOCTYPE html>
<html>
<head>
    <title>Unauthorized Access</title>
</head>
<body>
    <h1>Unauthorized Access</h1>
    <p>Sorry, you do not have permission to access this page.</p>
    <a href="index.php">Return to Home Page</a>
</body>
</html>