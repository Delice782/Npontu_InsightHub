-- phpMyAdmin SQL Dump
-- version 5.2.1deb3
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Dec 17, 2024 at 11:37 PM
-- Server version: 8.0.40-0ubuntu0.24.04.1
-- PHP Version: 8.3.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `webtech_fall2024_delice_ishimwe`
--

-- --------------------------------------------------------

--
-- Table structure for table `contact_submissions`
--

CREATE TABLE `contact_submissions` (
  `id` int NOT NULL,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `message` text NOT NULL,
  `submission_date` timestamp NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `contact_submissions`
--

INSERT INTO `contact_submissions` (`id`, `name`, `email`, `message`, `submission_date`) VALUES
(1, 'Betty', 'bettybenimana075@gmail.com', 'Hurrayyyy', '2024-12-15 17:20:16'),
(3, 'Be', 'deliceishimwe95@gmail.com', 'web app final test!', '2024-12-15 17:24:38'),
(4, 'Be', 'deliceishimwe95@gmail.com', 'web app final test!', '2024-12-15 17:24:42'),
(5, 'Betty', 'bettybenimana075@gmail.com', 'ffinal test for web app', '2024-12-15 17:25:53'),
(6, 'Betty', 'bettybenimana075@gmail.com', 'ffinal test for web app', '2024-12-15 17:26:26'),
(7, 'Dahlia', 'bettybenimana075@gmail.com', 'Web app test!', '2024-12-15 17:30:14'),
(8, 'Betty', 'bettybenimana075@gmail.com', 'ffinal test for web app', '2024-12-15 17:38:06'),
(9, 'Dahlia Igiraneza', 'dahlia.igiraneza.me@gmail.com', 'I am testing this webapp. It looks clean to me. Great job!!!!', '2024-12-15 19:05:58'),
(10, 'uwiteka', 'ada@gmail.com', 'a;ljd;aljdlad', '2024-12-17 21:20:21');

-- --------------------------------------------------------

--
-- Table structure for table `InsightHub_Feedback`
--

CREATE TABLE `InsightHub_Feedback` (
  `feedback_id` int NOT NULL,
  `user_id` int NOT NULL,
  `rating` int DEFAULT NULL,
  `comment` text,
  `category` enum('usability','performance','design','other') DEFAULT 'other',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `feedback_status` enum('pending','responded','resolved') DEFAULT 'pending',
  `response` text,
  `response_date` timestamp NULL DEFAULT NULL
) ;

--
-- Dumping data for table `InsightHub_Feedback`
--

INSERT INTO `InsightHub_Feedback` (`feedback_id`, `user_id`, `rating`, `comment`, `category`, `created_at`, `feedback_status`, `response`, `response_date`) VALUES
(4, 4, 5, 'performance was top-norch and design was visually appealing. gratefil!', 'performance', '2024-12-08 02:48:08', 'responded', 'thank you Betty fro giving us feedback! we appreciate!', '2024-12-15 11:22:56'),
(5, 5, 5, 'The software yoou gave me was top norch in all. gratefull!', 'performance', '2024-12-08 22:55:20', 'responded', 'oh our bad', '2024-12-15 11:21:02'),
(12, 4, 5, 'The design was awesome', 'design', '2024-12-10 01:15:45', 'pending', NULL, NULL),
(13, 4, 5, 'ur product are customer centered. Keep it up!', 'design', '2024-12-10 01:47:03', 'responded', 'thx', '2024-12-16 02:36:33'),
(33, 4, 4, 'hollaaaaaaaaa', 'design', '2024-12-15 13:26:28', 'pending', NULL, NULL),
(34, 4, 5, 'Holayyy!!!!!!!!!!', 'performance', '2024-12-15 13:26:44', 'pending', 'hiii', '2024-12-15 14:06:12'),
(36, 15, 5, 'Heyyy your products and services are appreciated. Just to say a few!', 'performance', '2024-12-15 14:23:21', 'pending', 'Thank you so much for your feedback. It\'s highly appreciated.', '2024-12-15 21:41:09'),
(38, 1, 5, 'your service are wonderful. keep it up!', 'performance', '2024-12-16 00:44:04', 'pending', NULL, NULL),
(39, 1, 5, 'well done on your job', 'performance', '2024-12-16 01:11:50', 'responded', 'thanks Del!', '2024-12-16 02:10:12'),
(40, 1, 5, 'well done on your job', 'usability', '2024-12-16 01:29:01', 'responded', 'thx', '2024-12-16 02:36:52'),
(41, 4, 5, 'Your services are nice!', 'other', '2024-12-16 14:17:47', 'pending', ' Thank You!', '2024-12-17 22:01:48'),
(42, 4, 5, 'design is inc!', 'design', '2024-12-16 14:18:12', 'responded', 'Thx', '2024-12-16 14:49:43'),
(45, 4, 5, 'The Snowlley AI is user friendly. I enjoy using it!', 'usability', '2024-12-17 00:45:53', 'pending', NULL, NULL),
(46, 4, 5, 'The software you gave me works perfectly. Thanks!', 'performance', '2024-12-17 00:46:41', 'pending', NULL, NULL),
(47, 4, 5, 'The software you gave me works perfectly. Thanks!', 'performance', '2024-12-17 00:47:07', 'responded', ' Thank You!', '2024-12-17 22:02:12'),
(52, 1, 5, 'Your services are nice!', 'other', '2024-12-17 14:08:09', 'responded', ' Thank you!', '2024-12-17 21:32:44'),
(56, 29, 1, 'Features are advertised, but they don\'t work as expected.', 'performance', '2024-12-17 15:01:37', 'pending', NULL, NULL),
(57, 1, 5, 'Your products are really good performing', 'performance', '2024-12-17 15:50:23', 'responded', ' Thank you!', '2024-12-17 21:32:16'),
(58, 31, 5, 'Snowlley AI works well!', 'performance', '2024-12-17 21:07:45', 'pending', ' Thank you so much. This is appreciated!', '2024-12-17 21:19:30');

-- --------------------------------------------------------

--
-- Table structure for table `InsightHub_FeedbackResponses`
--

CREATE TABLE `InsightHub_FeedbackResponses` (
  `response_id` int NOT NULL,
  `feedback_id` int NOT NULL,
  `user_id` int NOT NULL,
  `responder_id` int NOT NULL,
  `response_text` text NOT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `is_read` tinyint(1) DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- --------------------------------------------------------

--
-- Table structure for table `InsightHub_FeedbackTags`
--

CREATE TABLE `InsightHub_FeedbackTags` (
  `id` int NOT NULL,
  `feedback_id` int NOT NULL,
  `tag_id` int NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- --------------------------------------------------------

--
-- Table structure for table `InsightHub_Tags`
--

CREATE TABLE `InsightHub_Tags` (
  `tag_id` int NOT NULL,
  `tag_name` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- --------------------------------------------------------

--
-- Table structure for table `InsightHub_Users`
--

CREATE TABLE `InsightHub_Users` (
  `user_id` int NOT NULL,
  `name` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(255) NOT NULL,
  `role` enum('admin','customer') NOT NULL DEFAULT 'customer',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `profile_picture_url` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `InsightHub_Users`
--

INSERT INTO `InsightHub_Users` (`user_id`, `name`, `email`, `password`, `role`, `created_at`, `profile_picture_url`) VALUES
(1, 'Delico delii', 'del@gmail.com', '$2y$10$sRU9paH.yRKtpL6igTJE7Oq0Yqx5mdQRZytiAnZkNwjioCb7cz2xm', 'customer', '2024-12-05 20:52:33', NULL),
(4, 'Betty Benimana', 'betty@gmail.com', '$2y$10$92ybexZ6na4Vtx4xcpLVhOkcw3j6wLR6n4QSt.H2xHz8y6ZSqQhy6', 'customer', '2024-12-05 21:31:24', NULL),
(5, 'Titi Kubwimana', 'titi@gmail.com', '$2y$10$v.SnheCmx6rvP3YSMtX92.RlO8WUsXXWwutjHUHfhjhvljOR1e1je', 'customer', '2024-12-08 01:57:19', NULL),
(7, 'Divine Igirubuntu', 'divine@gmail.com', '$2y$10$W3Vjagv/1MsZZecRYkIeFOJaIZEd9d1lY/hIUXOQyIDYhPo.MlPb2', 'customer', '2024-12-10 02:30:31', NULL),
(8, 'Sam Sayubu', 'sam@gmail.comm', '$2y$10$FTcSVDhu4ZZ4M2c.HAFdtemReR1HkxmIGUu/e0gXzhil0tRxseB12', 'customer', '2024-12-10 02:32:55', NULL),
(14, 'Dahlia Igiraneza', 'dahlia@gmail.com', '$2y$10$YNt8pX61nBx.wDR1Nv/iXOWOgjORDM1u5D0mgfhoUOHJNg5QMhMi2', 'admin', '2024-12-15 14:17:28', NULL),
(15, 'Girukwayo Jean Baptiste', 'girukwayo@gmail.com', '$2y$10$12WwjnVNUlxh/Z/0LMXKQ.AwtNPmk1xjoqJAy2L7Tc.wpVmk8W8ka', 'customer', '2024-12-15 14:18:14', NULL),
(18, 'Delice Uwera', 'deliceishimwe95@gmail.com', '$2y$10$zcVJS1/QiNNM.5x661MbD.0hBmB5a/kwUAKAOUaKzMV9ZD3jI5PQO', 'admin', '2024-12-16 22:01:19', NULL),
(21, 'Emeline Mpenzi', 'emeline@gmail.com', '$2y$10$nTVtJ6Q2PLHmrn.fG0u4JeuX4Ax3uIEhtlxGkoRImPbscTbuXSiim', 'customer', '2024-12-17 02:21:01', NULL),
(23, 'Marie Muka', 'marie@gmail.com', '$2y$10$VFmKhJvXsuZB6k/U45T16.CvP/yhNClV.DBTkL92.JpZ.J9foffvm', 'customer', '2024-12-17 02:28:00', NULL),
(25, 'Titi Brown', 'brown@gmail.com', '$2y$10$BZ2UWF3inTUxOsooE/XswOaQnQaZgEVXfUBqgGwVDz4a767IMUnwC', 'customer', '2024-12-17 14:38:41', NULL),
(27, 'Erasto Dukuzimana', 'dukuze@gmail.com', '$2y$10$rQpMdfTpGAS5yjpqEEFXIe6djKJtYjNWR1vj1.fKjE3v.4skjuzEu', 'admin', '2024-12-17 14:39:30', NULL),
(28, 'Regis Igira', 'regis@gmail.com', '$2y$10$CPBRz6NnnzC6t2o6HraMUOksupOmWpyXbtq0stJv2fX3iMtBP.Ht6', 'customer', '2024-12-17 14:40:08', NULL),
(29, 'Dosita Igira', 'dosita@gmail.com', '$2y$10$8VAYXq3xrUC8oJ3G0oZJXOKlqaYIxNgGgEq3qxiqC9DlkseBHBoKq', 'customer', '2024-12-17 14:40:45', NULL),
(31, 'Delice Ishimweeeee', 'ishimwe@gmail.com', '$2y$10$AN/7rbd/7VfJ93dgSu0i9uDNVTkgg63BlPEvRfy1RhJ7oMEDnSmCe', 'customer', '2024-12-17 21:05:47', NULL),
(33, 'Thomas Sankara', 'sankara@gmail.com', '$2y$10$4AO82oDh7DcAdD6JW7MNAenxGZlhb8CusWXhggeadf3VicwUPlqnW', 'customer', '2024-12-17 21:55:06', NULL),
(34, 'Sam Coke', 'coke@gmail.com', '$2y$10$VPducM/UKT.CEyyG2UcvF.VsiIpfnRCs9ZdfCQzGPC61Qh3YjFn76', 'admin', '2024-12-17 21:59:03', NULL);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `contact_submissions`
--
ALTER TABLE `contact_submissions`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `InsightHub_Feedback`
--
ALTER TABLE `InsightHub_Feedback`
  ADD PRIMARY KEY (`feedback_id`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `InsightHub_FeedbackResponses`
--
ALTER TABLE `InsightHub_FeedbackResponses`
  ADD PRIMARY KEY (`response_id`),
  ADD KEY `user_id` (`user_id`),
  ADD KEY `feedback_id` (`feedback_id`);

--
-- Indexes for table `InsightHub_FeedbackTags`
--
ALTER TABLE `InsightHub_FeedbackTags`
  ADD PRIMARY KEY (`id`),
  ADD KEY `feedback_id` (`feedback_id`),
  ADD KEY `tag_id` (`tag_id`);

--
-- Indexes for table `InsightHub_Tags`
--
ALTER TABLE `InsightHub_Tags`
  ADD PRIMARY KEY (`tag_id`),
  ADD UNIQUE KEY `tag_name` (`tag_name`);

--
-- Indexes for table `InsightHub_Users`
--
ALTER TABLE `InsightHub_Users`
  ADD PRIMARY KEY (`user_id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `contact_submissions`
--
ALTER TABLE `contact_submissions`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `InsightHub_Feedback`
--
ALTER TABLE `InsightHub_Feedback`
  MODIFY `feedback_id` int NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `InsightHub_FeedbackResponses`
--
ALTER TABLE `InsightHub_FeedbackResponses`
  MODIFY `response_id` int NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `InsightHub_FeedbackTags`
--
ALTER TABLE `InsightHub_FeedbackTags`
  MODIFY `id` int NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `InsightHub_Tags`
--
ALTER TABLE `InsightHub_Tags`
  MODIFY `tag_id` int NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `InsightHub_Users`
--
ALTER TABLE `InsightHub_Users`
  MODIFY `user_id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=35;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `InsightHub_Feedback`
--
ALTER TABLE `InsightHub_Feedback`
  ADD CONSTRAINT `InsightHub_Feedback_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `InsightHub_Users` (`user_id`) ON DELETE CASCADE;

--
-- Constraints for table `InsightHub_FeedbackResponses`
--
ALTER TABLE `InsightHub_FeedbackResponses`
  ADD CONSTRAINT `InsightHub_FeedbackResponses_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `InsightHub_Users` (`user_id`),
  ADD CONSTRAINT `InsightHub_FeedbackResponses_ibfk_2` FOREIGN KEY (`feedback_id`) REFERENCES `InsightHub_Feedback` (`feedback_id`);

--
-- Constraints for table `InsightHub_FeedbackTags`
--
ALTER TABLE `InsightHub_FeedbackTags`
  ADD CONSTRAINT `InsightHub_FeedbackTags_ibfk_1` FOREIGN KEY (`feedback_id`) REFERENCES `InsightHub_Feedback` (`feedback_id`) ON DELETE CASCADE,
  ADD CONSTRAINT `InsightHub_FeedbackTags_ibfk_2` FOREIGN KEY (`tag_id`) REFERENCES `InsightHub_Tags` (`tag_id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
